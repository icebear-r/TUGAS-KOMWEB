<?php include '../includes/header.php'; ?>
<?php include '../includes/connection.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h2 class="mb-0">Tambah Data Biodata</h2>
                </div>
                <div class="card-body">
                    <form action="create.php" method="POST" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                                <input type="text" class="form-control" id="nama" name="nama" required>
                                <div class="invalid-feedback">
                                    Nama harus diisi.
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="alamat" class="form-label">Alamat</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-house-fill"></i></span>
                                <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                                <div class="invalid-feedback">
                                    Alamat harus diisi.
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                                <input type="email" class="form-control" id="email" name="email" required>
                                <div class="invalid-feedback">
                                    Email harus diisi dengan format yang benar.
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="telepon" class="form-label">Telepon</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-telephone-fill"></i></span>
                                <input type="tel" class="form-control" id="telepon" name="telepon" required pattern="[0-9]{10,13}">
                                <div class="invalid-feedback">
                                    Nomor telepon harus diisi (10-13 digit).
                                </div>
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" name="submit" class="btn btn-primary">
                                <i class="bi bi-plus-circle me-2"></i>Tambah Data
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
if (isset($_POST['submit'])) {
    $nama = htmlspecialchars($_POST['nama']);
    $alamat = htmlspecialchars($_POST['alamat']);
    $email = htmlspecialchars($_POST['email']);
    $telepon = htmlspecialchars($_POST['telepon']);

    $sql = "INSERT INTO biodata (nama, alamat, email, telepon) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nama, $alamat, $email, $telepon);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success mt-3' role='alert'>
                <i class='bi bi-check-circle-fill me-2'></i>Data berhasil ditambahkan
              </div>";
        echo "<script>
                setTimeout(function() {
                    window.location.href = 'read.php';
                }, 2000);
              </script>";
    } else {
        echo "<div class='alert alert-danger mt-3' role='alert'>
                <i class='bi bi-exclamation-triangle-fill me-2'></i>Error: " . $stmt->error . "
              </div>";
    }
    $stmt->close();
}

include '../includes/footer.php';
?>

<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()
</script>