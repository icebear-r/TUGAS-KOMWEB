<?php include '../includes/header.php'; ?>
<?php include '../includes/connection.php'; ?>

<div class="container">
  <h2>Daftar Biodata</h2>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Email</th>
        <th>Telepon</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = "SELECT * FROM biodata";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
              echo "<tr>
                      <td>{$row['id']}</td>
                      <td>{$row['nama']}</td>
                      <td>{$row['alamat']}</td>
                      <td>{$row['email']}</td>
                      <td>{$row['telepon']}</td>
                      <td>
                        <a href='update.php?id={$row['id']}' class='btn btn-info'>Edit</a>
                        <a href='delete.php?id={$row['id']}' class='btn btn-danger'>Delete</a>
                      </td>
                    </tr>";
          }
      } else {
          echo "<tr><td colspan='6'>Data tidak ditemukan</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>

<?php include '../includes/footer.php'; ?>
