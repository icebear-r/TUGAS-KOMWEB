<?php include '../includes/header.php'; ?>
<?php include '../includes/connection.php'; ?>

<div class="container">
    <h2>Edit Data Biodata</h2>

    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT * FROM biodata WHERE id=$id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    ?>

    <form action="update.php?id=<?php echo $id; ?>" method="POST">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $row['nama']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" required><?php echo $row['alamat']; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="telepon" class="form-label">Telepon</label>
            <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo $row['telepon']; ?>" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Update</button>
    </form>

    <?php
        } else {
            echo "Data tidak ditemukan!";
        }
    }

    if (isset($_POST['submit'])) {
        $nama = $_POST['nama'];
        $alamat = $_POST['alamat'];
        $email = $_POST['email'];
        $telepon = $_POST['telepon'];

        $sql = "UPDATE biodata SET nama='$nama', alamat='$alamat', email='$email', telepon='$telepon' WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Data berhasil diupdate</div>";
            header('Location: read.php');
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>

</div>

<?php include '../includes/footer.php'; ?>
