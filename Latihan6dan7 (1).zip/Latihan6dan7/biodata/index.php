<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biodata Pribadi - Sistem Manajemen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">Biodata Pribadi</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pages/read.php">Lihat Data</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pages/create.php">Tambah Data</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <!-- Hero Section -->
        <div class="hero-section">
            <div class="container-fluid py-5">
                <h1 class="display-5 fw-bold">Selamat Datang di Biodata Pribadi</h1>
                <p class="col-md-8 fs-4">
                    Website ini dibuat untuk mengelola biodata pribadi Anda dengan mudah menggunakan fitur CRUD. 
                    Silakan tambahkan, ubah, atau hapus data sesuai keinginan Anda.
                </p>
                <a href="pages/read.php" class="btn btn-primary btn-lg">
                    <i class="bi bi-eye-fill me-2"></i>Lihat Data Biodata
                </a>
            </div>
        </div>

        <!-- Features Section -->
        <div class="row text-center mt-5">
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 feature-card">
                    <div class="card-body">
                        <i class="bi bi-person-plus-fill feature-icon"></i>
                        <h5 class="card-title">Tambah Data</h5>
                        <p class="card-text">Tambahkan biodata baru dengan mudah dan cepat.</p>
                        <a href="pages/create.php" class="btn btn-success">
                            <i class="bi bi-plus-circle me-2"></i>Tambah Data
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 feature-card">
                    <div class="card-body">
                        <i class="bi bi-list-ul feature-icon"></i>
                        <h5 class="card-title">Lihat Biodata</h5>
                        <p class="card-text">Lihat daftar lengkap biodata yang telah Anda tambahkan.</p>
                        <a href="pages/read.php" class="btn btn-info">
                            <i class="bi bi-eye me-2"></i>Lihat Data
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 feature-card">
                    <div class="card-body">
                        <i class="bi bi-pencil-square feature-icon"></i>
                        <h5 class="card-title">Kelola Data</h5>
                        <p class="card-text">Edit atau hapus biodata yang sudah ada sesuai kebutuhan.</p>
                        <a href="pages/read.php" class="btn btn-warning">
                            <i class="bi bi-gear me-2"></i>Kelola Data
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light mt-5 py-3">
        <div class="container text-center">
            <p>&copy; 2023 Biodata Pribadi. Hak Cipta Dilindungi.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>