<footer class="footer mt-auto py-3 bg-light">
  <div class="container">
    <span class="text-muted">&copy; 2024 - Website Biodata Pribadi</span>
  </div>
</footer>

<script src="../js/bootstrap.bundle.min.js"></script> <!-- Bootstrap JS -->
<script src="../js/script.js"></script> <!-- Custom JS -->
</body>
</html>
